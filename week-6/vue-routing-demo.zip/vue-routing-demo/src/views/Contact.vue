<template>
  <div class="about">
    <h1>This is a contact page</h1>
  </div>
</template>
