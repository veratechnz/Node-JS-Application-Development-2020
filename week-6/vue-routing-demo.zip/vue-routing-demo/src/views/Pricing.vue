<template>
  <div class="about">
    <h1>This is the pricing page</h1>
  </div>
</template>

<style media="screen">

</style>
